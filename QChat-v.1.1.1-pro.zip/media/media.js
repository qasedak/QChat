var MEDIA = [
{
    title: "وودی وودپکر",
    file: "media/woody2.mp3"
},

{
    title: "این چیه؟",
    file: "media/bugs_mail.mp3"
},

{
    title: "دووه!",
    file: "media/doh.mp3"
},

{
    title: "سلام ...؟",
    file: "media/hello_butthead.mp3"
},

{
    title: "اینم ایمیل!",
    file: "media/mail_here.mp3"
},

{
    title: "برمی گردم!",
    file: "media/beback.mp3"
},

{
    title: "درد سر!",
    file: "media/big_trouble.mp3"
},

{
    title: "درسته!",
    file: "media/correctamundo.mp3"
},

{
    title: "بازی تموم شد پسر...",
    file: "media/gameover.mp3"
},

{
    title: "تولدت مبارک",
    file: "media/happy_birthday.mp3"
},

{
    title: "بوس",
    file: "media/kiss.mp3"
},

{
    title: "گربه",
    file: "media/cat.mp3"
},

{
    title: "سگ",
    file: "media/dog.mp3"
}
];