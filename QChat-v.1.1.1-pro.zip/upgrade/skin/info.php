<?php

$_INFO = array(
    'title' => 'Upgrade Skin',
    'author_name' => 'Elfet',
    'author_email' => 'chat@elfet.ru',
    'author_site' => 'http://elfchat.ru',
    'view_path' => 'upgrade/skin',
    'img_path' => 'skin/img',
    'css' => array(
        'main' => 'skin/main.css'
    ),
);
?>
