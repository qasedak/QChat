<input type="checkbox" name="<?=$id?>" value="<?=$value?>" <?=($checked?'checked':'')?> >
