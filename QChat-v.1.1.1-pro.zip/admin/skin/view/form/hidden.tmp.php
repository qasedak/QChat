<input type="hidden" name="<?=$id?>" value="<?=escape($value)?>">
