<td>
<?
echo date('j.m.Y G:i', $item);
?>
</td>
