<td  class="dragHandle">
<img src="<?=imgpath()?>/control_order.png" title="<?=tr('To change order drag this.')?>" alt="===">
</td>
