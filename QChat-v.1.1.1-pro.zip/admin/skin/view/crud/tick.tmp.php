<td align="center">
<? if($item): ?>
    <img src="<?=imgpath()?>/tick.png" alt="yes">
<? endif; ?>
</td>
