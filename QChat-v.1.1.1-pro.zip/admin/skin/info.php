<?php
$_INFO = array(
'view_path' => 'admin/skin/view',
'img_path' => 'skin/img',
'css' => array(
    'main' => 'skin/main.css',
    'spec' => 'skin/spec.css',
    )
);
?>
