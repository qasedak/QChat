<?php

$_INFO = array(
    'title' => 'Test Skin',
    'author_name' => 'Elfet',
    'author_email' => 'chat@elfet.com',
    'author_site' => 'http://elfet.ru',
    'view_path' => 'skin/original/view',
    'img_path' => 'skin/original/img',
    'css' => array(
        'chat' => 'skin/original/chat.css',
        'login' => 'skin/original/login.css',
        'override' => 'skin/test/override.css'
    )
);
?>
