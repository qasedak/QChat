<?php

$_INFO = array(
    'title' => 'qasedak',
    'author_name' => 'محمد عنبرستانی',
    'author_email' => 'info@omsh.ir',
    'author_site' => 'http://socialtools.ir',
    'view_path' => 'skin/qasedak/view',
    'img_path' => 'skin/qasedak/img',
    'css' => array(
        'chat' => 'skin/qasedak/chat.css',
        'login' => 'skin/qasedak/login.css',
        'override' => 'skin/qasedak/override.css'
    ),
);
?>
