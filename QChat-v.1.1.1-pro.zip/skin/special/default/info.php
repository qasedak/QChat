<?php

$_INFO = array(
    'title' => 'Default Skin',
    'author_name' => 'Elfet',
    'author_email' => 'chat@elfet.ru',
    'author_site' => 'http://elfchat.ru',
    'view_path' => 'skin/special/default/view',
    'img_path' => 'skin/special/default/img',
    'css' => array(
        'main' => 'skin/special/default/main.css'
    ),
);
?>
