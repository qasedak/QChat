<?php

$_INFO = array(
    'title' => 'Original Skin',
    'author_name' => 'Elfet',
    'author_email' => 'chat@elfet.ru',
    'author_site' => 'http://elfchat.ru',
    'view_path' => 'skin/original/view',
    'img_path' => 'skin/original/img',
    'css' => array(
        'chat' => 'skin/original/chat.css',
        'login' => 'skin/original/login.css',
        'override' => 'skin/original/override.css'
    ),
);
?>
