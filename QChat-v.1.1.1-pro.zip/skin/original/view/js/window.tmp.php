
<div class="window">
    <div class="top">
        <span class="title">{=title}</span>
        <div class="buttons" style="float:right;">
            <a href="#" class="button"><img src="<?= imgpath() ?>/cross_circle_frame.png"  alt=""></a>
        </div>
    </div>
    <div class="content">
        {=content}
    </div>
</div>
