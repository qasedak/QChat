<?php
$_LANG = array(
    '#lang' => 'English',
);
?>
